<?php

namespace StoneFarmMCHC;

use pocketmine\plugin\PluginBase as PluginBase;
use pocketmine\event\Listener as Listener;
use pocketmine\utils\TextFormat;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\block\Block;
use pocketmine\inventory\ShapedRecipe;
use pocketmine\nbt\NBT;
use pocketmine\block\Air;
use pocketmine\block\Stone;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
class Main extends PluginBase implements Listener{

 
	public function onEnable(){
	    $this->getServer()->getPluginManager()->registerEvents($this,$this);		
		$this->saveDefaultConfig();
			
		foreach($this->getCfg() as $craft) {
         $result = $this->getItem($craft["result"]);
            $rec = new ShapedRecipe($result, "ABC", "DEF", "GHI");
            $rec->setIngredient("A", $this->getItem($craft["shape"][0][0]));
            $rec->setIngredient("B", $this->getItem($craft["shape"][0][1]));
            $rec->setIngredient("C", $this->getItem($craft["shape"][0][2]));
            $rec->setIngredient("D", $this->getItem($craft["shape"][1][0]));
            $rec->setIngredient("E", $this->getItem($craft["shape"][1][1]));
            $rec->setIngredient("F", $this->getItem($craft["shape"][1][2]));
            $rec->setIngredient("G", $this->getItem($craft["shape"][2][0]));
            $rec->setIngredient("H", $this->getItem($craft["shape"][2][1]));
            $rec->setIngredient("I", $this->getItem($craft["shape"][2][2]));
            $this->getServer()->getCraftingManager()->registerRecipe($rec);
             $this->getLogger()->info("Crafting zostal wlaczony na:" . $this->getItem($craft["result"])->getName());
	        	$this->getServer()->getLogger()->info("
		    §cNazwa: StoneFarmMCHC
        §cWersja: 1.2
        §cOpis: Plugin dodaje stoniarki jak na mchc
        §cCzy kupiony: Nie
        §cAutor: Kiczan
        §cStrona do aktualizacji: Chwilowo brak :(
        §cCzy beda aktualizacje: Tak
        §cOstatnia aktualizacja: 15.06.18
        
        §cDziekuje za pobranie wersji: FREE
        ");
     } //Jezeli jest u ciebie tutaj czerowy kod to nie zwracaj uwagi
}
    public function getItem(array $item) : Item {
        $result = Item::get($item[0]);
        if(isset($item[1])) {
            $result->setCount($item[1]);
        }
        if(isset($item[2])) {
            $tags = $exception = null;
			$data = $item[2];
			try{
				$tags = NBT::parseJSON($data);
			}catch (\Throwable $ex){
				$exception = $ex;
			}

			if(!($tags instanceof \pocketmine\nbt\tag\CompoundTag) or $exception !== null){
				$this->getLogger()->warning(new \pocketmine\event\TranslationContainer("commands.give.tagError", [$exception !== null ? $exception->getMessage() : "Invalid tag conversion"]));
				return $result;
			}
            
            $result->setNamedTag($tags);
        }
        return $result;
    }
    
    
    private function getCfg() {
        return yaml_parse(file_get_contents($this->getDataFolder() . "config.yml"));
    }
	 public function onBreak(BlockBreakEvent $event){
	  $blok = $event->getBlock();
	  $gracz = $event->getPlayer();
	  $y = $blok->getFloorY();
	  $x = $blok->getFloorX();
  	 $z = $blok->getFloorZ();
  	  if($blok->getId() == 24){
	   $task = new Task($this, $event->getBlock()->getFloorX(), $event->getBlock()->getFloorY(), $event->getBlock()->getFloorZ());
       $this->getServer()->getScheduler()->scheduleDelayedTask($task, 30);
  	      }
  	    }
   public function trueCustomDrops(BlockBreakEvent $event){
	$player = $event->getPlayer();
	$block = $event->getBlock();
	$x = $block->getX();
	$y = $block->getY();
	$z = $block->getZ();
	if($player->getGamemode() == 0){
		if($block->getId() == 24){
		if(!$event->isCancelled()){
		$drops = array(Item::get(0, 0, 1));
		$event->setDrops($drops);
		if(!$event->isCancelled()){
		if($player->getInventory()->canAddItem(Item::get(24, 0, 1))){
		$player->getInventory()->addItem(Item::get(4, 0, 1));
		}
		else{
		$player->getLevel()->dropItem(new Vector3($x, $y, $z), Item::get(4, 0, 1));
		   }
		}
		}
		}
		}
		}
	 public function onPlace(BlockPlaceEvent $event){
	 $blok = $event->getBlock();
	 $gracz = $event->getPlayer();
	 $y = $blok->getFloorY();
	 $x = $blok->getFloorX();
	 $z = $blok->getFloorZ();
	 
  	 if($blok->getId() == 24){
  	  if(!($event->isCancelled())){

     $gracz->sendMessage("§8• [§6StoneFarmMCHC§8]§7 Postawiles stoniarke! §cAby ja zniszczyc kliknij na nia zlotym kilofem! §8•");
        $center = new Vector3($x, $y, $z);
        for($yaw = 0, $y = $center->y; $y < $center->y + 3; $yaw += (M_PI * 2) / 20, $y += 1 / 20) {
            $x = -sin($yaw) + $center->x;
            $z = cos($yaw) + $center->z;
    }
	  }else{
	   $gracz->sendMessage("§8• [§6StoneFarmMCHC§8]§7 Nie mozesz tutaj postawic Stoniarki! §8•");
	  }
	 }
	 }
	public function onInteract(PlayerInteractEvent $event){
		$gracz = $event->getPlayer();
		$item = $gracz->getItemInHand();
		$block = $event->getBlock();
		if($gracz->getInventory()->getItemInHand()->getId() === 285 && $block->getId() === 24){
		if($event->isCancelled()) return;
			$pos = new Vector3($block->x, $block->y, $block->z);
			$gracz->getLevel()->setBlock($pos, Block::get(0));
			$gracz->getLevel()->dropItem($pos, Item::get(Block::SANDSTONE, 0, 1));
            $gracz->sendMessage("§8• [§6StoneFarmMCHC§8]§7 Zniszczyles stoniarke! §8•");
			$it = Item::get($item->getId(), $item->getDamage() + 26, $item->getCount());
		}
	}
	}